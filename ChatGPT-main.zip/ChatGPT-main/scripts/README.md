# ChatGPT Scripts

> ChatGPT Desktop Application Core Extension Scripts.

[ChatGPT/scripts](https://github.com/lencx/ChatGPT/tree/main/scripts)
